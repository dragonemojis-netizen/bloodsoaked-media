================================================================================
Ar nosurge: Ode to an Unborn Star
21:9 Ultrawide Patch
BETA RELEASE
================================================================================

Part of the upcoming Bloodsoaked Media ultrawide patch collection.


================================================================================
SUPPORTED VERSION
================================================================================

Game title:     Ar nosurge: Ode to an Unborn Star
Region:         USA (SCEA)
Title ID:       BLUS31478
Tested update:  APP_VER 01.01 / VERSION 01.00 (disc install with game data
                installed to the PS3 emulator HDD)

PPU hash:       PPU-6bba06a48dedf608a6b658b52256327caa8c1426
                (RPCS3 identifies this hash when loading the game)

Target display: 21:9 ultrawide (developed and tested at 3440x1440)

OTHER REGIONS, REVISIONS, GAME UPDATES, AND TITLE IDs ARE UNTESTED.
This BETA is intended only for BLUS31478 with the PPU hash listed above.
If your copy shows a different title ID or PPU hash in RPCS3, these patches
may not apply and are not supported in this release.


================================================================================
BETA / TESTING STATUS
================================================================================

THIS IS A BETA RELEASE.

- It has NOT been exhaustively tested.
- Testing was limited to the author's own legally obtained USA (BLUS31478)
  copy, RPCS3 setup, and play sessions described in the project notes.
- Other regions, revisions, game versions, RPCS3 builds, GPUs, and display
  configurations may not work.
- Some dialogue cameras, cutscenes, HUD elements, menus, and special scenes
  are known or likely to behave differently or remain unpatched.
- You MUST provide your own legally obtained copy of the game.
- RPCS3 itself is NOT included in this download.
- NO copyrighted game content is included in this package.


================================================================================
WHAT THE PATCHES DO
================================================================================

This package contains ONE RPCS3 patch file with FIVE selectable patch entries.
Enable all five together for the supported BETA setup.

All patches require "Stretch To Display Area" in RPCS3 (see Recommended
Configuration below). The game renders to an internal 1280x720 framebuffer;
Stretch maps that to your ultrawide window while these patches adjust 3D
projection and selected UI layout for 21:9.


1. Ar Nosurge 21:9 - Field & Combat 1.0
   Status:     REQUIRED (for field and combat 3D Hor+)
   What:       Widens field exploration and combat 3D camera projection so
               the world fills left-to-right on 21:9 instead of looking
               pillarboxed or incorrectly scaled.
   Expect:     More horizontal view in the field and in combat. Works with
               the other four patches.
   Conflicts:  None with the other four patches in this file.


2. Ar Nosurge 21:9 - Dialogue Camera 1.0
   Status:     REQUIRED (for dialogue 3D Hor+ on supported talk scenes)
   What:       Adjusts the dialogue-scene 3D camera aspect for 21:9.
   Expect:     Dialogue scenes that use the patched camera path show wider
               3D framing instead of a stretched or narrow view.
   Conflicts:  None with the other four patches in this file.
   Limitation: Visually validated on ONE tested dialogue camera setup
               (Delta / Gennori outdoor ruins). Other talk cameras may still
               look wrong.


3. Ar Nosurge 21:9 - Dialogue UI 1.0
   Status:     REQUIRED (for dialogue message window sizing/placement)
   What:       Resizes and repositions the main dialogue message window for
               21:9 proportion and lower rest placement.
   Expect:     The blue dialogue text box is smaller (correct width for 21:9)
               and sits nearer the bottom of the screen than the unpatched
               stretched layout.
   Conflicts:  None with the other four patches in this file.
   Limitation: Message window only. Title bar, Log, Send, and other HUD are
               not fully covered by this patch.


4. Ar Nosurge 21:9 - Cutscene Camera 1.0
   Status:     REQUIRED (for supported engine/scripted cutscene 3D Hor+)
   What:       Adjusts type-6 engine/scripted cutscene 3D camera aspect for
               21:9.
   Expect:     Supported cutscenes show wider 3D framing on ultrawide.
   Conflicts:  None with the other four patches in this file.
   Limitation: Visually validated on ONE tested type-6 cutscene (Ion /
               gashapon field scene). Other event or camera types may still
               look wrong.


5. Ar Nosurge 21:9 - Field HUD 1.0
   Status:     REQUIRED (for field encounter bar layout)
   What:       Resizes and repositions the top-left field encounter bar for
               21:9.
   Expect:     The encounter bar is proportioned for ultrawide instead of
               appearing overly wide or misplaced.
   Conflicts:  None with the other four patches in this file.
   Limitation: Encounter bar only (uil_fm_encount). Bottom-right party talk
               HUD and other field UI are not patched.


MUTUALLY EXCLUSIVE OPTIONS

The five patches above are designed to run TOGETHER. Do not enable older or
experimental Ar nosurge 21:9 patches alongside this file if you have them from
earlier development builds. Those research patches are NOT included in this
BETA and share the same game hooks.


================================================================================
INSTALLATION FOR RPCS3
================================================================================

You need:
- A legally obtained copy of Ar nosurge: Ode to an Unborn Star (BLUS31478)
- RPCS3 installed and configured to run the game
- This ZIP extracted locally

STEP 1 — Copy the patch file

Copy the included file:

    ArNosurge_21x9_Ultrawide_Beta.yml

into your RPCS3 patches folder. Typical locations:

    Windows:  <RPCS3 install folder>\patches\
    Linux:    ~/.config/rpcs3/patches/   (or your RPCS3 data directory)

Do NOT overwrite RPCS3's official patch database file (patch.yml). Add this
as a NEW file. RPCS3 loads user patch YAML files from the patches folder
alongside the official database.

If you already use imported_patch.yml for other games or patches, you may
merge the contents of this file into imported_patch.yml instead of adding a
separate file. Do not remove unrelated patches from your existing setup.

STEP 2 — Restart RPCS3

Close and reopen RPCS3 so it rescans patch files.

STEP 3 — Enable the patches

1. Right-click the game in the RPCS3 game list.
2. Choose "Manage" -> "Game Patches" (wording may vary slightly by RPCS3
   version).
3. Find the five entries whose names begin with "Ar Nosurge 21:9 -".
4. Enable ALL FIVE:
     - Ar Nosurge 21:9 - Field & Combat 1.0
     - Ar Nosurge 21:9 - Dialogue Camera 1.0
     - Ar Nosurge 21:9 - Dialogue UI 1.0
     - Ar Nosurge 21:9 - Cutscene Camera 1.0
     - Ar Nosurge 21:9 - Field HUD 1.0
5. Save/confirm and close the patch manager.

STEP 4 — Configure display settings

In RPCS3 game or custom configuration for BLUS31478:

    Stretch To Display Area:  ON   (REQUIRED)
    Aspect ratio:             16:9
    Resolution:               1920 x 1080  (author's tested baseline)
    Resolution Scale:         200%         (author's tested baseline)
    Renderer:                 Vulkan       (author's tested baseline)

These patches were developed with Stretch ON. Without Stretch, the ultrawide
layout will not match the tested behavior.

STEP 5 — Restart the game

Fully restart the game after changing patches or display settings.


================================================================================
RECOMMENDED BETA SETUP
================================================================================

Quick start:

1. Enable:  Ar Nosurge 21:9 - Field & Combat 1.0
2. Enable:  Ar Nosurge 21:9 - Dialogue Camera 1.0
3. Enable:  Ar Nosurge 21:9 - Dialogue UI 1.0
4. Enable:  Ar Nosurge 21:9 - Cutscene Camera 1.0
5. Enable:  Ar Nosurge 21:9 - Field HUD 1.0
6. Set:     Stretch To Display Area = ON
7. Set:     Aspect ratio = 16:9
8. Optional: Frame Limit = 120 in RPCS3 (tested by author; not a patch)
9. Restart the game.

Do NOT enable older experimental Ar nosurge XP-* research patches if present
in your RPCS3 install from prior development.


================================================================================
KNOWN LIMITATIONS
================================================================================

CONFIRMED / DOCUMENTED

- Internal render target remains 1280x720. Ultrawide is achieved with Stretch
  plus Hor+ projection/UI adjustments, not a native 3440-wide framebuffer.
- Dialogue Camera 1.0: proven on ONE tested talk 3D camera only.
- Cutscene Camera 1.0: proven on ONE tested type-6 engine cutscene only.
- Field HUD 1.0: top-left encounter bar only; party talk HUD unchanged.
- Dialogue UI 1.0: main message window only; other UI not fully audited.
- Dialogue message window transition animation may still look imperfect in
  some scenes.

UNTESTED / OUT OF SCOPE FOR THIS BETA

- Regions other than USA BLUS31478
- Game updates or revisions other than the tested APP_VER 01.01 setup
- JP/EU title IDs
- Menus, title screen, Log/Send prompts, bottom-right talk HUD, FMVs, anime
  videos, and other UI not listed above
- Native render-target Hor+ approaches (earlier experiments were unsafe)
- High frame rates beyond the author's tested Frame Limit 120 configuration
- Non-ultrawide or non-Stretch display setups


================================================================================
TESTING PERFORMED (AUTHOR ENVIRONMENT)
================================================================================

The following areas were tested and marked PASS in project notes:

- Field 3D Hor+
- Combat 3D Hor+ (same mechanism as field)
- Dialogue 3D Hor+ on one tested talk scene
- Dialogue message window scale/placement
- Type-6 cutscene 3D Hor+ on one tested cutscene
- Field encounter HUD bar (Flask Sea area)
- All five patches enabled together without hook conflicts
- Frame Limit 120 via RPCS3 settings (optional; not included as a patch)

Testing was NOT exhaustive across the full game.


================================================================================
TROUBLESHOOTING
================================================================================

Patches do not appear in Game Patches:
- Confirm ArNosurge_21x9_Ultrawide_Beta.yml is in the RPCS3 patches folder.
- Restart RPCS3 completely.
- Confirm you are opening patches for BLUS31478 / the correct game entry.

Game looks unchanged:
- Confirm all five "Ar Nosurge 21:9 -" patches are enabled.
- Confirm Stretch To Display Area is ON.
- Restart the game after enabling patches.

Game looks wrong / broken:
- Disable all five patches and restart to confirm baseline behavior.
- Remove any older experimental Ar nosurge XP-* patches from your RPCS3
  patches folder or disable them in Game Patches.
- Confirm your copy is BLUS31478 with PPU hash
  PPU-6bba06a48dedf608a6b658b52256327caa8c1426.

Only some scenes look wrong:
- Expected for this BETA. Some cameras and UI elements are not patched.
  See Known Limitations.


================================================================================
CREDITS
================================================================================

Patch development: Dakota / Cursor
Distribution:       Bloodsoaked Media ultrawide patch collection (BETA)

Ar nosurge: Ode to an Unborn Star is property of its respective owners.
This project is a fan-created RPCS3 patch. It is not affiliated with or
endorsed by Gust, Koei Tecmo, Sony, or RPCS3 developers.


================================================================================
LEGAL / SCOPE
================================================================================

This release contains ONLY:
- User-created RPCS3 patch file(s)
- This README.txt

This release does NOT include:
- Game files, ISOs, PKGs, RAPs, updates, DLC, firmware, BIOS, saves,
  RPCS3 binaries, extracted game assets, or any other copyrighted content.

You must provide your own legally obtained copy of the game and your own
RPCS3 installation.

Use at your own risk.
