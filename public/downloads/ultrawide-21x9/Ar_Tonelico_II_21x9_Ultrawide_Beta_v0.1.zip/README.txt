================================================================================
AR TONELICO II 21:9 ULTRAWIDE PATCH
BETA RELEASE
================================================================================

AR TONELICO II: MELODY OF METAFALICA
21:9 ULTRAWIDE PATCH
BETA RELEASE


--------------------------------------------------------------------------------
SUPPORTED VERSION
--------------------------------------------------------------------------------

Ar tonelico II: Melody of Metafalica
USA / NTSC-U
SLUS-21788
CRC: F95F37EE

This patch is for that version only.


--------------------------------------------------------------------------------
TESTING STATUS
--------------------------------------------------------------------------------

This is a BETA release.

It is functional for the portions that have been personally tested, but it has
NOT been exhaustively tested.

Testing was performed only with the author's own legally obtained disc dump /
ISO of the USA / NTSC-U version listed above (CRC F95F37EE).

Other versions, regions, revisions, and CRCs are untested. Do not assume
compatibility with PAL, Japanese, or any other release.

Users must provide and use their own legally obtained copy of the game.

No game files are included with this download. This package contains only a
user-created PCSX2 patch and this README.


--------------------------------------------------------------------------------
WHAT THE PATCH DOES
--------------------------------------------------------------------------------

- Adapts the game's gameplay / field presentation for 21:9 ultrawide displays.
- Uses a custom rendering / projection patch rather than simply stretching the
  gameplay image.
- Includes the current battle rendering handling required by the 21:9 patch.
- Is intended for use with PCSX2.

This does NOT claim that every camera, scene, UI element, or game mode is fixed.


IMPORTANT:

This patch is a BETA release and currently has known issues with dialogue / talk
presentation. Please read the Known Limitations section before installing.


--------------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------------

1. Close PCSX2 completely.

2. Locate your PCSX2 user data directory, then open the "cheats" folder.
   On Windows, this is commonly:

     Documents\PCSX2\cheats\

   If you use a portable PCSX2 install, use that install's cheats folder
   instead.

3. Copy F95F37EE.pnach into the PCSX2 cheats folder.
   The filename must remain exactly:

     F95F37EE.pnach

4. In PCSX2, enable cheats for the game
   (Enable Cheats / game properties cheats, depending on your PCSX2 version).

5. Disable any conflicting built-in widescreen patch for Ar tonelico II.
   Turn OFF "Enable Widescreen Patches" for this title so the official 16:9
   patch does not fight this 21:9 cheat file.

6. Configure display / aspect settings for 21:9:
   - Use a 21:9 ultrawide display or 21:9 window.
   - Set PCSX2's Aspect Ratio / display scaling behavior to Stretch
     ("Fit to Window / Fullscreen" in some PCSX2 versions).
   - The patch itself requests gsaspectratio=21:9.

7. Cold boot / fully restart the game after installing or changing the patch.
   Do not rely only on reloading cheats while the game is already running.


--------------------------------------------------------------------------------
KNOWN LIMITATIONS (BETA)
--------------------------------------------------------------------------------

The major unresolved area is dialogue / talk presentation.

- Dialogue portraits may appear horizontally stretched.
- Dialogue boxes and frames may appear horizontally stretched.
- Dialogue text may appear horizontally stretched.
- Some talk-scene presentation may not display correctly at 21:9.

Also unverified or only lightly covered:

- FMV behavior has not been fully addressed or verified.
- Special cameras, minigames, late-game content, and unusual scenes may not
  have been fully tested.

These are beta limitations and unverified areas. Untested features are not
claimed to be definitely broken.


--------------------------------------------------------------------------------
TROUBLESHOOTING
--------------------------------------------------------------------------------

If the patch does not apply or looks wrong:

- Confirm the game is the USA / NTSC-U version (SLUS-21788).
- Confirm the CRC is F95F37EE.
- Confirm cheats are enabled in PCSX2.
- Confirm F95F37EE.pnach is in the correct PCSX2 cheats folder.
- Disable conflicting built-in widescreen patches for this title.
- Remove older or experimental Ar Tonelico II PNACH files for this CRC so only
  this release file remains active.
- Fully restart / cold boot PCSX2 (and the game) after changing the patch.


--------------------------------------------------------------------------------
CREDITS
--------------------------------------------------------------------------------

Nemesis2000 — original PCSX2 16:9 widescreen patch that helped inform the
investigation. This credit does not imply endorsement, testing, or direct
involvement by Nemesis2000 in this beta release.

BPDStarvedBeast — 21:9 adaptation, reverse engineering, testing, and
documentation.


--------------------------------------------------------------------------------
LEGAL / SCOPE
--------------------------------------------------------------------------------

This download is only a user-created PCSX2 patch and a text README.

Provide your own legally obtained copy of the game.
Do not redistribute copyrighted game content with this patch.

Intended emulator: PCSX2.
Other emulators are unsupported / untested.


================================================================================
End of README — Ar Tonelico II 21:9 Ultrawide Patch — BETA
================================================================================
