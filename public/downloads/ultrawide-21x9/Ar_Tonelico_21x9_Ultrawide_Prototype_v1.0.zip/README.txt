Ar tonelico: Melody of Elemia
21:9 Ultrawide Patch
PROTOTYPE RELEASE

============================================================
SUPPORTED VERSION
============================================================

Game title:  Ar tonelico: Melody of Elemia
Region:      USA
Serial:      SLUS-21445
CRC:         4437F4B1

This prototype is intended ONLY for the USA version identified
above. Other regions, revisions, and CRCs are untested.

============================================================
PROTOTYPE / TESTING STATUS
============================================================

This is a PROTOTYPE release.

It is an experimental 21:9 implementation and has not been
exhaustively tested.

Testing has been performed only with the author's own legally
obtained copy of the supported USA game version
(SLUS-21445 / CRC 4437F4B1).

Other regions, revisions, CRCs, emulator versions, and
configurations are untested.

Users must provide their own legally obtained copy of the game.

No game files or copyrighted game content are included in this
download.

This is intentionally a PROTOTYPE, not a Beta, and not a
complete or production-ready ultrawide conversion.

============================================================
WHAT THE PATCH DOES
============================================================

This prototype adapts the community 16:9 widescreen approach
into a 21:9 Hor+ style presentation for supported 3D paths:

- Applies a 21:9 horizontal projection scale on the shared 3D
  perspective builder used by gameplay cameras.
- Adapts battle / shared-scene left-right bounds from the
  official 16:9 values for the wider framing.
- Includes a matching 2D / UI scaler Method A path.
- Optionally includes a No-Interlacing section (separate from
  the main 21:9 section).

Where applicable, normal field exploration and battles can
benefit from expanded horizontal gameplay framing with
correct character and world proportions (not a simple
horizontal stretch of the whole image).

What this patch does NOT do:

- It does not create new artwork or geometry outside the
  original authored scene content.
- It does not remaster FMVs / IPU / MPEG cutscenes.
- It does not claim every menu, dialogue plate, portrait,
  background, or UI element is corrected for ultrawide.
- It does not make the game a native 21:9 framebuffer title.

============================================================
KNOWN LIMITATIONS — IMPORTANT
============================================================

Some scenes and visual elements were authored around the
original aspect ratio. Expanding the gameplay viewport cannot
create new artwork or geometry outside content that never
existed.

Confirmed limitations:

- Dialogue / event scenes may show empty or black regions at
  the sides. Those scenes use dedicated authored background
  assets built for the original framing. This was experimentally
  investigated (including clip-volume expansion tests); the
  empty sides are an authored-content limitation, not a setting
  users can fix.
- Pre-rendered FMV / IPU / MPEG material remains at its original
  presentation and is out of scope for this PNACH.
- Perfect HUD / UI centering and complete correction of every
  2D element are not claimed.
- Logical PS2 rendering resolution is unchanged; this patch
  adjusts projection and related scales.

Untested / outside prototype scope:

- Other regions and CRCs
- Exhaustive coverage of every menu, portrait layout, and
  scripted scene
- Residual experimental UI-extent ideas that were intentionally
  excluded from this prototype
- Creating or replacing dialogue background art

============================================================
INSTALLATION
============================================================

1. Close PCSX2 completely.
2. Locate your PCSX2 cheats folder
   (commonly Documents\PCSX2\cheats).
3. Copy 4437F4B1.pnach into the cheats folder.
4. Preserve the exact filename: 4437F4B1.pnach
   (PCSX2 matches cheats by game CRC).
5. Enable Cheats for this game.
6. Disable any conflicting built-in / community 16:9
   Widescreen patch for this title (do not stack both).
7. In the cheat list for this game, enable:
      [Widescreen 21:9 Final]
   Optionally enable:
      [No-Interlacing]
8. Set PCSX2 graphics Aspect Ratio to:
      Fit to Window / Screen
   (as required by this prototype).
9. Cold boot / fully restart the game after changing patches
   or cheat selections.

============================================================
RECOMMENDED PROTOTYPE SETUP
============================================================

1. Enable:  [Widescreen 21:9 Final]
2. Optional: [No-Interlacing]
3. Disable: built-in / community 16:9 Widescreen for this title
4. Set Aspect Ratio: Fit to Window / Screen
5. Cold boot the game

============================================================
WHAT TO EXPECT
============================================================

- Normal field exploration and battles may benefit from
  expanded horizontal framing with correct proportions.
- World map traversal is part of the intended prototype
  experience.
- Some dialogue or scripted scenes may expose empty side
  regions because of original authored backgrounds.
- FMVs generally keep their original presentation.
- Treat this as an experimental enhancement, not a complete
  ultrawide conversion of every screen.

============================================================
CREDITS
============================================================

Nemesis2000 — original official PCSX2 16:9 widescreen
implementation for this title (foundation for this work).
No endorsement by Nemesis2000 is implied.

NineKain — No-Interlacing section.

BPDStarvedBeast — 21:9 adaptation, reverse engineering,
testing, and documentation.

============================================================
LEGAL / SCOPE
============================================================

This download contains only a user-created PCSX2 patch and
documentation.

No game files or copyrighted game content are included.

Users must provide their own legally obtained copy of the game.

PCSX2 is not included.

Based on the published prototype baseline:
https://github.com/dragonemojis-netizen/ArTonelico-21x9
Release v1.0.0 (artonelico219.rar) — patch bytes unchanged.
